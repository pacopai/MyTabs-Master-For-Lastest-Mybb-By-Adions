<?php

	/*
	 *	MyBBPlugins
	 *	http://www.mybbplug.in/s/
	 *
	 *	MyTabs
	 *	Created by FatalMessiah at MyBBPlugins
	 *	[Administrator & Developer]
	 *      origanaly Created by Ethan at MyBBPlugins
	 *	- File: "{$mybb->settings['bburl']}/inc/plugins/mytabs.php"
	 *
	 *  This plugin and its contents are free for use.
	 *
	 */

	$plugins->add_hook("index_start", "mytabs_start");
	$plugins->add_hook("index_end", "mytabs_forums");
	$plugins->add_hook("usercp_options_end", "mytabs_useroptions");
	$plugins->add_hook("usercp_do_options_end", "mytabs_save_useroptions");
	$plugins->add_hook("admin_forum_menu", "mytabs_menu");
	$plugins->add_hook("admin_forum_action_handler", "mytabs_action_handler");
	
	function mytabs_info()
	{
		return array(
			'name'			=> 'MyTabs',
			'description'	=> 'Lets you implement tabbed browsing in your forum.',
			'website'		=> 'leakbd.com',
			'author'		=> 'Adions',
			'authorsite'	=> 'https://leakbd.com',
			'version'		=> '1.32',
			'guid'			=> '88a15ee0474822feb1a78044daae64bd'
		);
	}

	function mytabs_activate()
	{
		global $mybb, $db;
		
		/* Create table for storing tabs. */
		if ( !$db->table_exists( 'mytabs' ) )
		{
			$mytabs_table = 'CREATE TABLE `'.TABLE_PREFIX.'mytabs` (
											`id` INT( 10 ) NOT NULL AUTO_INCREMENT ,
											`name` TEXT NOT NULL ,
											`forums` TEXT NOT NULL ,
											`visible` TEXT NOT NULL ,
											`order` TEXT NOT NULL ,
											`tab_code` TEXT NOT NULL ,
											`selected_tab_code` TEXT NOT NULL ,
											PRIMARY KEY ( `id` )
											) ENGINE = MYISAM ;
								';
			$db->query( $mytabs_table );
		}
		
		/* Create settings table. */
		if ( !$db->table_exists( 'mytabs_settings' ) )
		{
			$mytabs_table = 'CREATE TABLE `'.TABLE_PREFIX.'mytabs_settings` (
											`id` INT( 10 ) NOT NULL AUTO_INCREMENT ,
											`name` TEXT NOT NULL ,
											`value` TEXT NOT NULL ,
											PRIMARY KEY ( `id` )
											) ENGINE = MYISAM ;
								';
			$db->query( $mytabs_table );
		}
		
		/* Create default settings. */
		
		$default_settings[] = array(
			'id' => 1,
			'name' => 'enabled',
			'value' => '1'
		);
		
		$default_settings[] = array(
			'id' => 2,
			'name' => 'default_tab_code',
			'value' => '<td class="thead" style="border: 1px solid black; margin-right: 5px; padding: 2px 5px 2px 5px;">\r\n	<div>\r\n		<a href="{$link}">{$name}</a>\r\n	</div>\r\n</td>\r\n'
		);
		
		$default_settings[] = array(
			'id' => 3,
			'name' => 'default_selected_tab_code',
			'value' => '<td class="thead" style="border: 1px solid black; margin-right: 5px; padding: 2px 5px 2px 5px;">\r\n	<div>\r\n		<strong><a href="{$link}">{$name}</a></strong>\r\n	</div>\r\n</td>'
		);
		
		$default_settings[] = array(
			'id' => 4,
			'name' => 'tab_list_code',
			'value' => '<table border="0" cellspacing="1" cellpadding="1" class="tdborder">\r\n		<tr>\r\n			{$tablist}\r\n		</tr>\r\n</table>'
		);
		
		$default_settings[] = array(
			'id' => 5,
			'name' => 'default_tab',
			'value' => '1'
		);
		
		$default_settings[] = array(
			'id' => 6,
			'name' => 'ajax',
			'value' => '1'
		);
		
		$db->insert_query_multiple('mytabs_settings', $default_settings);
		
		/* Create user default tab option column. */
		
		if ( !$db->field_exists( 'default_tab', 'users' ) )
		{
			$db->add_column('users', 'default_tab', 'TEXT NOT NULL DEFAULT 0');
		}
	}
	
	function mytabs_deactivate()
	{
		global $mybb, $db;
		
		/* Drop the tabs table. */
		if ( $db->table_exists( 'mytabs' ) )
		{
			$db->drop_table( 'mytabs' );
		}
		
		/* Drop the tabs settings table. */
		if ( $db->table_exists( 'mytabs_settings' ) )
		{
			$db->drop_table( 'mytabs_settings' );
		}
		
		/* Drop the user default tab option column. */
		if ( $db->field_exists( 'default_tab', 'users' ) )
		{
			$db->drop_column('users', 'default_tab');
		}
	}
	
	function mytabs_start()
	{
		global $db, $header, $headerinclude, $mybb;
		
		$query = $db->simple_select('mytabs_settings');
		while($result = $db->fetch_array($query))
		{
			$setting[$result['name']] = $result['value'];
		}
		
		if($setting['enabled'])
		{
			$headerinclude .= "<script type=\"text/javascript\" src=\"{$mybb->settings['bburl']}/jscripts/mytabs.js\"></script>";
		}
	}
	
	function mytabs_forums()
	{
		global $db, $forumpermissions, $forums, $mybb;
		
		$query = $db->simple_select('mytabs_settings');
		while($result = $db->fetch_array($query))
		{
			$setting[$result['name']] = $result['value'];
		}
		
		$selected_tab = intval($mybb->input['tab']);
		
		$query = $db->simple_select('users', 'default_tab', "`uid`='{$mybb->user['uid']}'");
		if($db->num_rows($query) > 0)
		{
			if($user_tab_info = $db->fetch_array($query))
			{
				$temp = rtrim($user_tab_info['default_tab']);
				if(!empty($temp))
				{
					if(empty($selected_tab))
					{
						$selected_tab = $db->escape_string($user_tab_info['default_tab']);
					}
				}
			}
		}
		
		if(intval($selected_tab) > 0)
		{
			$query = $db->simple_select('mytabs', '*', "id='{$selected_tab}'");
			if($temp_tab = $db->fetch_array($query))
			{
				if(!$temp_tab['visible'])
				{	
					if($setting['default_tab'] == 0)
					{
						$selected_tab = 1;
					}
					else
					{
						$selected_tab = $setting['default_tab'];
					}
				}
			}
			else
			{
				if($setting['default_tab'] == 0)
				{
					$selected_tab = 1;
				}
				else
				{
					$selected_tab = $setting['default_tab'];
				}
			}
		}
		else
		{
			if($setting['default_tab'] == 0)
			{
				$selected_tab = 1;
			}
			else
			{
				$selected_tab = $setting['default_tab'];
			}
		}
		
		$forums .= "\n<!-- mytabs (disabled): \$forum start -->\n<!-- mytabs_full_start --><div id=\"mytabs_full\">";
		if ($setting['enabled'])
		{
			if ($setting['ajax'])
			{
				$tab_query = $db->simple_select('mytabs', "*", '', array('order_by' => '`order`', 'order_dir' => 'asc'));
				
				if($db->num_rows($tab_query) > 0)
				{
					/* Start tab menu code. */
					while($tab = $db->fetch_array($tab_query))
					{
						/* If tab is selected, generate body content and propar nav button. */
						if($tab['id'] == $selected_tab)
						{
							$name = $tab['name'];
							$link = "?tab={$tab['id']}\" onclick=\"return switchTab('{$tab['id']}', 'true');";
							$temp = rtrim($tab['selected_tab_code']);
							if(!empty($temp)) {
								eval("\$tablist .= \"".$db->escape_string($tab["selected_tab_code"])."\";");
							} else {
								eval("\$tablist .= \"".$db->escape_string($setting["default_selected_tab_code"])."\";");
							}
							
							/* Check already unviewable forums, and save to array. */
							$noshow = array();
							foreach($forumpermissions as $fid => $perms)
							{
								if(!$forumpermissions[$fid]['canview'])
								{
									$noshow[] .= $fid;
								}
							}
							
							/* Set all the forums to invisible. */
							foreach($forumpermissions as $fid => $perms)
							{
								$forumpermissions[$fid]['canview'] = 0;
							}
							
							/* Make sure the tab has forums to exclude, otherwise show all. */
							$temp = rtrim($tab['forums']);
							if(!empty($temp))
							{
								foreach(explode(',', $tab['forums']) as $fid)
								{
									/* Re-Check if forum is already unviewable. */
									if($fid != null && is_array($noshow))
									{
										if(!in_array($fid, $noshow))
										{
											/* Set this forum viewable. */
											$forumpermissions[$fid]['canview'] = 1;
											
											/* Check parent forums and set to viewable. */
											$parents = get_parent_list($fid);
											$temp = rtrim($parents);
											if(!empty($temp))
											{
												foreach(explode(',', $parents) as $pid)
												{
													if($pid != null && !in_array($pid, $noshow))
													{
														$forumpermissions[$pid]['canview'] = 1;
													}
												}
											}
										}
									}
								}
								$forum_list = build_forumbits();
								$body_content = $forum_list['forum_list'];
							}
						}
						else
						{
							if(!$tab['visible'])
								continue;
							$name = $tab['name'];
							$link = "?tab={$tab['id']}\" onclick=\"return switchTab('{$tab['id']}', 'true');";
							$temp = rtrim($tab['tab_code']);
							if(!empty($temp)) {
								eval("\$tablist .= \"".$db->escape_string($tab["tab_code"])."\";");
							} else {
								eval("\$tablist .= \"".$db->escape_string($setting["default_tab_code"])."\";");
							}
						}
					}
					if(!empty($tablist))
					{
						eval("\$navbar .= \"".$db->escape_string(
							"<div id=\"tab_nav_{$selected_tab}\" style=\"\">".$setting['tab_list_code'])."</div>\";"
						);
					}
					else
					{
						$forums .= "<!-- mytabs: \$tablist = \"{$tablist}\" -->";
					}
					if(!empty($navbar) && !empty($body_content))
					{
						$forums = "<!-- mytabs: start (ajax) -->\n<!-- mytabs_full_start --><div id=\"mytabs_full\">\n";
						$forums .= "<div id=\"tab_navbar\">\n\r{$navbar}\n</div>\n<div id=\"tab_content\">\n\r{$body_content}\n</div>";
						$forums .= "\n<!-- mytabs_full_end --></div>\n<!-- mytabs: end -->";
					}
					else
					{
						$forums .= "<!-- mytabs: \$navbar = \"{$navbar}\" -->";
					}
				}
				else
				{
					$forums .= "<!-- mytabs: no tabs currently set (query turning 0 table result) -->";
				}
				$forums .= "<!-- mytabs: ajax version end -->";
				if(isset($mybb->input['output-mytab-code']))
				{
					$temp = str_replace('<!-- mytabs_full_start --><div id="mytabs_full">', '', $forums);
					$temp2 = str_replace('<!-- mytabs_full_end --></div>', '', $temp);
					die($temp2);
				}
			}
			else
			{
				$tab_query = $db->simple_select('mytabs', "*", '', array('order_by' => '`order`', 'order_dir' => 'asc'));
				
				if($db->num_rows($tab_query) > 0)
				{
					$forums = "";
			
					/* Start tab menu code. */
					
					$forums .= "\n<!-- mytabs: start -->\n<!-- mytabs_full_start --><div id=\"mytabs_full\">";
					
					$forums .= "\n<div id=\"tab_nav\">";
					
					$query = $db->simple_select('mytabs', '*', '', array('order_by' => '`order`', 'order_dir' => 'asc'));
					while($tab = $db->fetch_array($query))
					{
						if(!$tab['visible'])
							continue;
						$tablist = "";
						$query2 = $db->simple_select('mytabs', '*', '', array('order_by' => '`order`', 'order_dir' => 'asc'));
						while($tab2 = $db->fetch_array($query2))
						{
							if(!$tab2['visible'])
								continue;
							$name = $tab2['name'];
							$link = "?tab={$tab2['id']}\" onclick=\"return switchTab('{$tab2['id']}', false);";
							if($tab['id'] == $tab2['id'])
							{
								$temp = rtrim($tab['selected_tab_code']);
								if(!empty($temp)) {
									eval("\$tablist .= \"".$db->escape_string($tab["selected_tab_code"])."\";");
								} else {
									eval("\$tablist .= \"".$db->escape_string($setting["default_selected_tab_code"])."\";");
								}
							}
							else
							{
								$temp = rtrim($tab['tab_code']);
								if(!empty($temp)) {
									eval("\$tablist .= \"".$db->escape_string($tab["tab_code"])."\";");
								} else {
									eval("\$tablist .= \"".$db->escape_string($setting["default_tab_code"])."\";");
								}
							}
						}
						if($selected_tab == $tab['id'])
						{
							eval("\$forums .= \"".$db->escape_string(
								"<div id=\"tab_nav_{$tab['id']}\" style=\"\">".$setting['tab_list_code'])."</div>\";"
							);
						}
						else
						{
							eval("\$forums .= \"".$db->escape_string(
								"<div id=\"tab_nav_{$tab['id']}\" style=\"display: none;\">".$setting['tab_list_code'])."</div>\";"
							);
						}
					}
					$forums .= "\n</div>\n<div id=\"tab_content\" style=\"\">";
					
					/* End tab menu code. */
					
					$noshow = array();
					foreach($forumpermissions as $fid => $perms)
					{
						/* Check if forum is already unviewable. */
						if(!$forumpermissions[$fid]['canview'])
						{
							$noshow[] .= $fid;
						}
					}
					
					while($tab = $db->fetch_array($tab_query))
					{
						if(!$tab['visible'])
							continue;
						$forums .= "\n<!-- Starting with tab[{$tab['id']}] -->";
						if($tab['id'] == $selected_tab) {
							$forums .= "\n\n<!-- \$tab[{$tab['id']}] selected -->\n";
							$forums .= "\n<div id=\"tab_{$tab['id']}\" style=\"\">";
						} else {
							$forums .= "\n\n<!-- \$tab[{$tab['id']}] not selected -->\n";
							$forums .= "\n<div id=\"tab_{$tab['id']}\" style=\"display: none;\">";
						}
						/* Set all the forums to invisible. */
						foreach($forumpermissions as $fid => $perms)
						{
							$forumpermissions[$fid]['canview'] = 0;
						}
						$temp = rtrim($tab['forums']);
						/* Make sure the tab has forums to exclude, otherwise show all. */
						if(!empty($temp))
						{
							foreach(explode(',', $tab['forums']) as $fid)
							{
								/* Re-Check if forum is already unviewable. */
								if($fid != null && is_array($noshow))
								{
									if(!in_array($fid, $noshow))
									{
										/* Set this forum viewable. */
										$forumpermissions[$fid]['canview'] = 1;
										$forums .= "<!-- Setting forum[{$fid}] visible -->";
										
										/* Check parent forums and set to viewable. */
										$parents = get_parent_list($fid);
										if(!empty($parents))
										{
											foreach(explode(',', $parents) as $pid)
											{
												if($pid != null && !in_array($pid, $noshow))
												{
													$forumpermissions[$pid]['canview'] = 1;
													$forums .= "<!-- Setting parent[{$pid}] visible -->";
												}
											}
										}
									}
								}
							}
							$forum_list = build_forumbits();
							$forums .= "\n\n<!-- Start building tab[{$tab['id']}] contents -->\n\n";
							$forums .= $forum_list['forum_list'];
							$forums .= "\n\n<!-- End building tab[{$tab['id']}] contents -->\n\n";
						}
						else
						{
							$forums .= "\n<!-- mytabs: no forums set with this tab -->";
						}
						$forums .= "</div>";
						$forums .= "\n<!-- Finished with tab[{$tab['id']}] -->\n";
					}
					$forums .= "\n\n</div>\n<!-- mytabs_full_end --></div>";
					$forums .= "\n<!-- mytabs: end -->";
				}
				$forums .= "\n<!-- mytabs: javascript version end -->";
			}
		}
		else
		{
			/* Disabled */
			$forums .= "\n<!-- mytabs_full_end --></div>\n<!-- mytabs: setting disabled -->";
		}
	}
	
	function mytabs_useroptions()
	{
		global $db, $lang, $mybb, $templates, $tppselect;
		
		$query = $db->simple_select('mytabs_settings');
		while($result = $db->fetch_array($query))
		{
			$setting[$result['name']] = $result['value'];
		}
		
		if($setting['enabled'])
		{
			$lang->load('mytabs');
			
			$query = $db->simple_select('users', 'default_tab', "uid='{$mybb->user['uid']}'");
			if($db->num_rows($query) > 0)
			{
				if($user_tab_info = $db->fetch_array($query))
				{
					$temp = rtrim($user_tab_info['default_tab']);
					if(!empty($temp))
					{
						$selected_tab = $db->escape_string($user_tab_info['default_tab']);
					}
				}
			}
			
			$query = $db->simple_select("mytabs");
			if($db->num_rows($query) > 0)
			{
				while($tab = $db->fetch_array($query))
				{
					if($tab['visible'])
					{
						$selected = "";
						if($selected_tab == $tab['id'])
						{
							$selected = "selected=\"selected\"";
						}
						$tppoptions .= "<option value=\"{$tab['id']}\" $selected>{$tab['name']}</option>\n";
					}
				}
				eval("\$tabselect .= \"".$templates->get("usercp_options_tppselect")."\";");
				$tppselect .= str_replace('name="tpp"', 'name="defaulttab"', $tabselect);
			}
		}
	}
	
	function mytabs_save_useroptions()
	{
		global $db, $mybb;
		
		$query = $db->simple_select('mytabs_settings');
		while($result = $db->fetch_array($query))
		{
			$setting[$result['name']] = $result['value'];
		}
		
		if($setting['enabled'])
		{
			$db->update_query("users", array('default_tab' => intval($mybb->input['defaulttab'])), "uid='".$mybb->user['uid']."'");
		}
	}
	
	function mytabs_menu(&$sub_menu)
	{
		global $mybb, $lang;

		end($sub_menu);
		$key = (key($sub_menu))+10;

		if(!$key)
		{
			$key = '50';
		}
		$sub_menu[$key] = array('id' => 'mytabs', 'title' => 'MyTabs', 'link' => "index.php?module=forum-mytabs");
	}
	
	function mytabs_action_handler(&$action)
	{
		$action['mytabs'] = array('active' => 'mytabs', 'file' => 'mytabs.php');
	}

?>